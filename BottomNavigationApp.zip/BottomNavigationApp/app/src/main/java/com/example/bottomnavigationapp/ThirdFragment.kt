package com.example.bottomnavigationapp

import androidx.fragment.app.Fragment

class ThirdFragment: Fragment(R.layout.fragment_third) {
}